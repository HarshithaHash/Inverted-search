#include "invert_search.h"
#include <stdio.h>
#include <string.h>
#include <ctype.h>

Status Search_data(int index,char *word1, hash *hhead)
{
//check if hash index link is null or not, if null return data not found
	if(hhead[index].Hlink == NULL)
	{
		return DATA_NOT_FOUND;
	}
//if not null create main temp and assign hash index link to that
	else
	{
		main_node *temp = hhead[index].Hlink;
//iterate main temp till null
		while(temp)
		{
//compare given word and stored word is equal or not
			if(strcmp(temp -> word, word1) == 0)         //equal
			{
//if equal  print data of main node and sub node
				printf("[%d] - %s - %d", index,word1, temp -> file_count);
				sub_node *sub_temp = temp -> S_link;
				while(sub_temp)
				{
					printf("---> %s - %d", sub_temp -> filename, sub_temp -> word_count);
					sub_temp = sub_temp -> Slink;
				}
				printf("---> NULL\n");
				return SUCCESS;
			}
			temp = temp -> Mlink;	
		}
//if word not found return data not found
		return DATA_NOT_FOUND;
	}
}

