#include "invert_search.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

Status update_database(char *filename1, hash *hhead, main_node **main_head, sub_node **sub_head, sslist **newlist)
{
	int index = 0;
//open file that is entered by user and checked it is .txt, then check file pointer is null or not
	FILE *fptr_file = fopen(filename1, "r");
	if(fptr_file == NULL)
	{
		printf("Error: File %s is empty\n", filename1);
		return FAILURE;
	}
//if not null scan the content to string
	char str[100];
	while(fscanf(fptr_file, "%s", str) != EOF)
	{
//to check if that is saved file, check starting charater is # or not
		if(str[0] == '#')
		{
//if true then get index value by using strtok
			index = atoi(strtok(&str[1], ";"));
//and check hash index link is null or not 
			if(hhead[index].Hlink == NULL)
			{
//if null, create main node and sub node and enter the main node data and for subnode run loop till filecount and enter  
				main_node *m_temp = malloc(sizeof(main_node));
				if(m_temp == NULL)
				{
					printf("Error: memory allocation failed\n");
					return FAILURE;
				}
				sub_node *s_temp = malloc(sizeof(sub_node));
				if(s_temp == NULL)
				{
					printf("Error: Memory allocation failed\n");
					return FAILURE;
				}
				strcpy(m_temp -> word, strtok(NULL, ";"));
				m_temp -> file_count = atoi(strtok(NULL, ";"));
				m_temp -> Mlink = NULL;
				strcpy(s_temp -> filename, strtok(NULL, ";"));
				s_temp -> word_count = atoi(strtok(NULL, ";"));
				s_temp -> Slink = NULL;
				m_temp -> S_link = s_temp;
				sub_node *prev = s_temp;
				for(int i = 1; i < m_temp -> file_count; i++)
				{
					sub_node *s_new1 = malloc(sizeof(sub_node));
					if(s_new1 == NULL)
					{
						printf("Error: memory is not allocated\n");
						return FAILURE;			
					}
					strcpy(s_new1 -> filename, strtok(NULL, ";"));
					s_new1 -> word_count = atoi(strtok(NULL, ";"));
					s_new1 -> Slink = NULL;
					prev -> Slink = s_new1;
					prev = s_new1;
				}
				hhead[index].Hlink = m_temp;
		}
//if not null, then traverse the main link till null. create and insert the data and update the link 
		else
		{
			main_node *m_new = malloc(sizeof(main_node));
			if(m_new == NULL)
			{
				printf("Error: memory is not allocated\n");
			}
			sub_node *s_new = malloc(sizeof(sub_node));
			if(s_new == NULL)
			{
				printf("Error: memory is not allocated\n");
			}
			strcpy(m_new -> word, strtok(NULL, ";"));
			m_new -> file_count = atoi(strtok(NULL, ";"));
			m_new -> Mlink = NULL;
			strcpy(s_new -> filename, strtok(NULL, ";"));
			s_new -> word_count = atoi(strtok(NULL, ";"));
			s_new -> Slink = NULL;
			m_new -> S_link = s_new;
			sub_node *prev = s_new;
			for(int i = 1; i < m_new -> file_count; i++)
			{
				sub_node *s_new1 = malloc(sizeof(sub_node));
				if(s_new1 == NULL)
				{
					printf("Error: memory not allocated\n");
					return FAILURE;
				}
				strcpy(s_new1 -> filename, strtok(NULL, ";"));
				s_new1 -> word_count = atoi(strtok(NULL, ";"));
				s_new1 -> Slink = NULL;
				prev -> Slink = s_new1;
				prev = s_new1;
			}
			main_node *temp = hhead[index].Hlink;
			while(temp -> Mlink != NULL)
			{
				temp = temp -> Mlink;
			}
			temp -> Mlink = m_new;
		}
	}
	}
	return SUCCESS;
}

