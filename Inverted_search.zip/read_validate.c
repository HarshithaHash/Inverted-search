#include "invert_search.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

//`int create_list(sslist **head, char *word);
Status read_and_validate(char *argv[], sslist **head,int argc)
{
	    FILE *fptr_file;
		for(int i = 1; i < argc; i++)
		{
//check in command passed file is .txt or not
			if(strcmp(strstr(argv[i], "."), ".txt") == 0)
			{
//if passed, open file and store to pointer
				fptr_file = fopen(argv[i], "r");
//check file pointer null or not	
				if(fptr_file == NULL)
				{
					printf("Warning: Unable to open file %s\n", argv[i]);
					continue;
				}
//if not, check inside file content present or not
				else
				{
					fseek(fptr_file, 0, SEEK_END);
					if(ftell(fptr_file) == 0)
					{
						printf("Warning: File %s is empty\n", argv[i]);
						continue;
					}
//if present perform insert at last operation to store filename inside linked list and ignore if it is duplicate file passed
					sslist *temp = *head;
					while(temp)
					{
						if(strcmp(temp -> file_name, argv[i]) == 0)
						{
							printf("Warning: Duplicate data found in the list for %s\n", argv[i]);
							break;
						}
						temp = temp -> link;
					}
					if(temp != NULL)
					{
						continue;
					}
					sslist *new = malloc(sizeof(sslist));
					if(new == NULL)
					{
						return FAILURE;
					}
					strcpy(new -> file_name, argv[i]);
					new -> link = NULL;
					if(*head == NULL)
					{
						*head = new;
						//printf("%s node created\n", argv[i]);
					}
					else
					{
						temp = *head;
						while(temp -> link)
						{
							temp = temp -> link;
						}
						temp -> link = new;
						//printf("%s node created\n", argv[i]);

					}
				}
				fclose(fptr_file);
			}
		}
		return SUCCESS;
}





