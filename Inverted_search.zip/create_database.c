#include "invert_search.h"
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>

Status database(sslist **head, hash *hhead, main_node **main_head, sub_node **sub_head)
{
//declare the varibale and pointers
	int index;
	char word[100];
	FILE *fptr_file;
	sslist *temp = *head;
//interate loop till null
	printf("file = %s\n", temp -> file_name);
	while(temp != NULL)
	{	
// open file and save it to file pointer
		fptr_file = fopen(temp -> file_name, "r");
//if file pointer null return failure
		if(fptr_file == NULL)
		{
			printf("file not opened\n");
			return FAILURE;
		}
//else, to ect the content use fscanf and store to string word
	   	else
		{
			while(fscanf(fptr_file, "%s", word) != EOF)
			{
//check if that word is alphabate or number or other charater . if alphabate subtract with 'a' and get index value and call function
				if('a' <=  word[0] && word[0] <= 'z' || 'A' <= word[0] && word[0] <= 'Z')
				{
					index = tolower(word[0]) - 'a';
					insert_data(index, hhead, word, temp -> file_name, main_head, sub_head);
				}
//if it is number store in index 26 and call function
				else if(isdigit(word[0]))
				{
					index = 26;
					insert_data(index, hhead, word, temp -> file_name, main_head, sub_head);
				}
//if any other character store it i index 27 and call function
				else
				{
					index = 27;
					insert_data(index, hhead, word, temp -> file_name, main_head, sub_head);
				}
			}
			printf("Database created successfully for : %s\n", temp -> file_name);
			fclose(fptr_file);
			temp = temp -> link;
		}
	}
	return SUCCESS;
}
#if 1
/*function defnition to insert the data*/
Status insert_data(int index, hash *hhead, char *word, char *file_name, main_node **main_head, sub_node **sub_head)
{
//if hash index table equal to null call main_node and sub_node function to add content and link main link to hashlink and sub link to main
	if(hhead[index].Hlink == NULL)
	{
		insert_main_node(main_head, word);
		insert_sub_node(sub_head, file_name);
		(*main_head) -> S_link = *sub_head;
		hhead[index].Hlink = *main_head;
	}
//if not equal, validate for words by comparing the words and temp of words and till last 
	else 
	{
		main_node *m_temp = hhead[index].Hlink;
		while(m_temp)
		{
//if words same, then compre filename
			if(strcmp(m_temp -> word, word) == 0)
			{
				sub_node *s_temp = m_temp -> S_link;
				while(s_temp)
				{
//if filename same increment the wordcount
					if(strcmp(s_temp -> filename, file_name) == 0)
					{
						(s_temp -> word_count)++;
						break;
					}
//if filename not same and sublink equal to null then update sub node and increament filecount
					else if((strcmp(s_temp -> filename, file_name) != 0) && (s_temp -> Slink == NULL))
					{
						insert_sub_node(sub_head, file_name);
						s_temp -> Slink = *sub_head;
						(m_temp -> file_count)++;
						break;
					}
					else
					{
						s_temp = s_temp -> Slink;
					}
				}
				break;
			}
//if words are different the update main and sub node and update main link
			else if((strcmp(m_temp -> word, word) != 0) && (m_temp -> Mlink == NULL))
			{
				insert_main_node(main_head, word);
				insert_sub_node(sub_head, file_name);
				(*main_head) -> S_link = (*sub_head);
	  			m_temp -> Mlink = *main_head;
				//printf("word = %s\n", m_temp -> word);
				break;	
			}
			m_temp = m_temp -> Mlink;
		}
	}
}

//update the main node
Status insert_main_node(main_node **main_head, char *word)
{
	main_node *m_new = malloc(sizeof(main_node));
	if(m_new == NULL)
	{
		printf("Error: memory is not allocated\n");
		return FAILURE;
	}
	m_new -> file_count = 1;
	strcpy(m_new -> word, word);
	m_new -> Mlink = NULL;
	*main_head = m_new;
}

//update the subnode
Status insert_sub_node(sub_node **sub_head, char *file_name)
{
	sub_node *s_new = malloc(sizeof(sub_node));
	if(s_new == NULL)
	{
		printf("Error: memory is not allocated\n");
		return FAILURE;
	}
	s_new -> word_count = 1;
	strcpy(s_new -> filename, file_name);
	s_new -> Slink = NULL;
	*sub_head = s_new;
}
#endif


	
	



