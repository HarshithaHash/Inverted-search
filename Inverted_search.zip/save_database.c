#include "invert_search.h"
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>


Status save_database(hash *hhead, main_node **main_head, char * filename1)
{
	char wd[20];
//cheak entered file is .txt or not
	if(strcmp(strstr(filename1, "."), ".txt") == 0)
	{
//if true open the file and store into filepointer and file pointer is null or not
		FILE *fptr_file = fopen(filename1, "w");
	   if(fptr_file == NULL)
	   {
		   printf("unable to open the file\n");
		   return FAILURE;
	   }
	 //iterate the loop 
	   for(int index = 0; index < 28; index++)
	   {
//if hash table index not null
	   		if(hhead[index].Hlink != NULL)
			{
//then, assign the hash index link to main temp
				main_node *mt = hhead[index].Hlink;
//and iterate till last node
				while(mt)
				{
//and save main node data and sub node data  inside entered file using fprintf 
					fprintf(fptr_file, "#%d;%s;%d;", index, mt -> word, mt -> file_count);
					sub_node *st = mt -> S_link;
					while(st)
				    {
						fprintf(fptr_file, "%s;%d;", st -> filename, st -> word_count);
					 	st = st -> Slink;
					}
					fprintf(fptr_file, "#\n");
					mt = mt -> Mlink;
				}
				
			}	
		}
	}
}
