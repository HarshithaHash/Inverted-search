/*
Name         : Harshitha V
Date         : 29/02/2024
Description  : Inverted search
*/

#include "invert_search.h"
#include <string.h>
//#include <unistd.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
/*declare the variables, array and pointers*/
	int ch,res;
	char ch1;
	char word[20];
	char filename1[20];
	sslist *head = NULL;
	sslist *newlist;
	hash hhead[100];
	create_hash_table(hhead);
	main_node *main_head = NULL;
	sub_node *sub_head = NULL;
	int flag = 1;
//check if argc value is greater than 1
	if(argc > 1)
	{
//if true call the read and validate function
		if(read_and_validate(argv, &head, argc) == SUCCESS)    
		{
//if success, traverse and print the files
			if(head == NULL)
			{
				printf("Error: No files are present\n");
				return FAILURE;
			}
			else
			{
				sslist *temp = head;
				while(temp)
				{
					printf("%s -> ", temp -> file_name);
					temp = temp -> link;
				}
				printf("NULL\n");
//do while loop to ask the user to continue or not
				do
				{
//menu for inverted search and enter the option 
					printf("1. Create Database\n2. Search Database\n3. Update Database\n4. Save Database\n5. Display Database\n");
					printf("Enter the option\n");
					scanf("%d", &ch);
					switch(ch)
					{
						case 1: 
	//choose 1, then call create data base 
							if(database(&head, hhead, &main_head, &sub_head) == SUCCESS)
							{
								flag = 0;
							//	printf("create database successfull\n");
							}
							else
							{
								printf("Error: can not create database again.\n");
							}
							break;
						case 5:
	//for option 5, call display database
							Display_data(hhead);
							break;
	//for option 2, call search data
						case 2:
							//char word1[30];
							printf("Enter the word to be searched: ");
							scanf("%s", word);                                //enter which word to search in database
							//int i =0;
							int i = tolower(word[0]) - 97;
							if(Search_data(i,word, hhead)== DATA_NOT_FOUND)
							{
								printf("ERROR: Data not found !. Please enter the correct word.\n");
							}
							break;
	//for option 4, call save database
						case 4:
							//char filename1[100];
							printf("Enter the filename to save the database: ");     //enter the file .txt to save database inside that
							scanf("%s", filename1);
							getchar();
							save_database(hhead, &main_head, filename1);
							printf("INFO: Database is saved to %s\n", filename1);
							break;
	//for option 3, call update database
						case 3:
							if(flag)
							{
								char filename2[30];
								printf("Enter updated file name : ");        //enter the file to be update
								scanf("%s", filename2);
								getchar();
								if(strcmp(strstr(filename2,"."), ".txt") == 0)   //compare if it is .txt or not if true call function
								{
									if(update_database(filename2, hhead, &main_head, &sub_head, &newlist) == SUCCESS)
									{
										if(check_update_database(&head, filename2) == SUCCESS)
										{
											printf("INFO: Database updated with %s\n", filename2);
										}
									}
								}
								else
								{
									printf("Error: enter only .txt extension file\n");
								}
							}
							else
							{
								printf("Error: Database is created already\n");
							}
							break;
			//exit 
						case 6:
							return SUCCESS;
							break;
			//default statement
						default:
							printf("Invalid\n");
							break;
					}
					printf("Do you want to continue ?\nEnter y/Y to continue (or) n/N to exit : ");
					scanf(" %c",&ch1);
					getchar();
				}while((ch1 == 'y') || (ch1 == 'Y'));
				//return SUCCESS;
			}
		}
		else
		{
			printf("Error: read and validate is unsuccessfull\n");
		}
	}
	else
	{
		printf("INFO : Enter the valid number of arguement\n");
	}
}

/*function to create hash table*/
void create_hash_table(hash *hasht)
{
	for(int i = 0; i < 28; i++)
	{
		hasht[i].index = i;
		hasht[i].Hlink = NULL;
	}
}

