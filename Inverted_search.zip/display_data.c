#include "invert_search.h"
#include <stdio.h>
#include <string.h>

Status Display_data(hash *hhead)
{
//iterate for loop till hash table index 0 to 27
	printf("[Index]\t[Word]\t[Filecount]\t[Wordcount]\t[Filename]\n");
	for(int i = 0; i < 28; i++)
	{
//check hash table is null or not, if null continue
		if(hhead[i].Hlink == NULL)
		{
			continue;
		}
//if not null create temp to main and assign that hash index link to that
		else
		{
			main_node *main_temp = hhead[i].Hlink;
//and iterate the main temp till null
			while(main_temp != NULL)
			{
//print main node data 
				printf("[%d]\t%s\t%d\t", i, main_temp -> word, main_temp -> file_count);
//and check is subnode is present or not if present print the sub node also
				sub_node *sub_temp = main_temp -> S_link;
				while(sub_temp != NULL)
				{
					printf("\t%s\t\t%d", sub_temp -> filename, sub_temp -> word_count);
					sub_temp = sub_temp -> Slink;
				}
				printf("\n");
			//	printf("las = %s\n", main_temp -> word);
				main_temp = main_temp -> Mlink;
			}
		}
	}
	printf("\n");
	return SUCCESS;
}
