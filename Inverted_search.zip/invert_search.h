#ifndef INVERT_SEARCH_H
#define INVERT_SEARCH_H

typedef struct node
{
	char file_name[20];
	struct node *link;
}sslist;
typedef struct sub
{
	int word_count;
	char filename[20];
	struct sub *Slink;
}sub_node;

typedef struct main
{
	int file_count;
	char word[20];
	struct sub *S_link;
	struct main *Mlink;
}main_node;

typedef struct hash_node
{
	int index;
	struct main *Hlink;
}hash;

typedef enum
{
	SUCCESS,
	FAILURE,
	EMPTY,
	DATA_NOT_FOUND
}Status;

/*Function prototype*/

/*function declaration create hash table*/
void create_hash_table(hash *hasht);

/*function decalration to read and vaidate*/
Status read_and_validate(char *argv[], sslist **head, int argc);

/*function declaration to create database*/
Status database(sslist **head, hash *hhead, main_node **main_head, sub_node **sub_head);

/*function declaration to insert data in database*/
Status insert_data(int index, hash *hhead, char *word, char *file_name, main_node **main_head, sub_node **sub_head);

/*to insert main node*/
Status insert_main_node(main_node **main_head, char *word);

/*to insert subnode*/
Status insert_sub_node(sub_node **sub_head, char *file_name);

/*to display the data*/
Status Display_data(hash *hhead);

/*to search the data*/
Status Search_data(int index, char *word1, hash *hhead);

/*to save database it to backup file*/
Status save_database(hash *hhead, main_node **main_head, char *filename1);

/*to update the database*/
Status update_database(char *filename1, hash *hhead, main_node **main_head, sub_node **sub_head, sslist **newlist);
/*cheak the file already created or not*/
Status check_update_database(sslist **head, const char *backup);
#endif
