#include "invert_search.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

//once update we cant updae again should ignore the files
Status check_update_database(sslist **head, const char *backup)
{
//open fill and store to file pointer and check 
	FILE *fp = fopen(backup, "r");
	if(fp == NULL)
	{
		printf("Error: Fail to open backupfaile %s\n", backup);
		return FAILURE;
	}
	char str[200];
//get content to string by fscanf
	while(fscanf(fp, "%s", str) != EOF)
	{
//should compare the if already updated or not so in backup file it stores like [eg: #0;are;2;file1.txt;1#] to get file use strtok to skip and reach to file position
		strtok(str, ";");                  //skip first
		strtok(NULL, ";");                 //skip 2nd
		strtok(NULL, ";");                 //skip 3rd
		char *file_name = strtok(NULL, ";");  // in 4th position file store to another variable to compare that
		strtok(NULL, ";");                 //5th skip
		strtok(file_name, "\n");           //remove new line
		sslist *temp = *head;              //assign single linked list head to temp
		sslist *prev = NULL;               //prev to null
		while(temp)
		{
			if(strcmp(temp -> file_name, file_name) == 0)         //compare the filename
			{
				if(prev == NULL)                 //if repeated, check prev pointing to null
				{
					*head = temp -> link;        //if true update head to next address
				}
				else
				{
					prev -> link = temp -> link;     //else update prev of link to next link
				}
				free(temp);                            //and free temp
				break;
			}
			prev = temp;                             //if not equal file assign temp to prev and temp to next
			temp = temp -> link;
		}
	}
	fclose(fp);
	return SUCCESS;
}
